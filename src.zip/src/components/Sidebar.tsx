import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import * as apiService from '@/services/api';
import { Home, LogOut, Settings, Upload } from 'lucide-react';
import keansaLogo from '@/images/keansa_logo.png'; // Existing logo import
import ruleConfigurationsIcon from '@/images/Rule Configurations.png'; // Import Rule Configurations icon
import dataValidationsIcon from '@/images/Data Validations.png'; // Import Data Validations icon
import autodatavalidationicon from '../images/sftp-icon.png'; // Import Auto Data Validation icon
import rulemanagementicon from '../images/Rule Management.png'; // Import Rules Management icon


export const Sidebar: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, setUser, setIsAuthenticated } = useAuth();

  const handleLogout = async () => {
    try {
      await apiService.logout();
      setUser(null);
      setIsAuthenticated(false);
      navigate('/login');
      toast({
        title: 'Success',
        description: 'Logged out successfully.',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to log out. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const isActive = (path: string) => {
    return location.pathname === path ? 'bg-gray-200' : '';
  };

  return (
    <div className="w-64 bg-white shadow-md flex flex-col h-screen">
      <div className="p-4 border-b flex items-center space-x-2">
        <img
          src={keansaLogo}
          alt="Keansa Logo"
          className="w-8 h-auto"
        />
        <h1 className="text-2xl font-bold text-gray-800">Keansa AI Suite</h1>
      </div>
      <nav className="flex-1 p-4 space-y-2">
        <Link to="/dashboard">
          <Button variant="ghost" className={`w-full justify-start ${isActive('/dashboard')}`}>
            <Home className="mr-2 h-5 w-5" />
            Home
          </Button>
        </Link>
        <Link to="/rule-configurations">
          <Button variant="ghost" className={`w-full justify-start ${isActive('/rule-configurations')}`}>
            <img src={ruleConfigurationsIcon} alt="Rule Configurations" className="mr-2 h-5 w-5" />
            Rule Configurations
          </Button>
        </Link>
        <Link to="/data-validations">
          <Button variant="ghost" className={`w-full justify-start ${isActive('/data-validations')}`}>
            <img src={dataValidationsIcon} alt="Data Validations" className="mr-2 h-5 w-5" />
            Data Validations
          </Button>
        </Link>
        <Link to="/auto-data-validation">
          <Button variant="ghost" className={`w-full justify-start ${isActive('/auto-data-validation')}`}>
            <img src={autodatavalidationicon} alt="Auto Data Validation" className="mr-2 h-5 w-5" />
            Auto Data Validation
          </Button>
        </Link>
        <Link to="/rules-management">
          <Button variant="ghost" className={`w-full justify-start ${isActive('/rules-management')}`}>
            <img src={rulemanagementicon} alt="Rules Management" className="mr-2 h-5 w-5" />
            Rules Management
          </Button>
        </Link>
      </nav>
      <div className="p-4 border-t">
        <Button variant="ghost" className="w-full justify-start">
          <Settings className="mr-2 h-5 w-5" />
          Settings
        </Button>
        <Button variant="ghost" className="w-full justify-start text-red-600" onClick={handleLogout}>
          <LogOut className="mr-2 h-5 w-5" />
          Logout
        </Button>
      </div>
    </div>
  );
};