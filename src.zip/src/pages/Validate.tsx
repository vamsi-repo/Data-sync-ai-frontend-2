import { DragDropContext, Droppable, Draggable, DropResult } from 'react-beautiful-dnd';
import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Input } from '../components/ui/input';
import { Progress } from '../components/ui/progress';
import { AlertCircle, Home, Download, ArrowLeft } from 'lucide-react';
import { useValidation } from '../contexts/ValidationContext';
import { toast } from '../hooks/use-toast';
import * as apiService from '../services/api';
import { Sidebar } from '../components/Sidebar';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { Label } from '../components/ui/label';

// Define TypeScript interfaces
interface TemplateResponse {
  sheets: { [key: string]: { headers: string[] } };
  file_name: string;
  file_path: string;
  sheet_name: string;
  has_existing_rules?: boolean;
  validations?: Record<string, string[]>;
}

interface ErrorLocation {
  row: number;
  value: string;
  rule_failed: string;
  reason: string;
}

interface Rule {
  rule_id: number | null | undefined;
  rule_type_id: number;
  rule_name: string;
  description: string;
  parameters: string;
  is_custom: boolean;
  column_name?: string;
  template_id?: number;
}

const validationOptions = ['Required', 'Int', 'Float', 'Text', 'Email', 'Date', 'Boolean', 'Alphanumeric'];

const Validate: React.FC = () => {
  const { templateId } = useParams<{ templateId: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { currentStep, setCurrentStep, headers, setHeaders, selectedHeaders, setSelectedHeaders, validations, setValidations, errorLocations, setErrorLocations, dataRows, setDataRows } = useValidation();
  const [loading, setLoading] = useState(true);
  const [fetchingErrors, setFetchingErrors] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sheetName, setSheetName] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  const [isReviewMode, setIsReviewMode] = useState(false);
  const [corrections, setCorrections] = useState<Record<string, Record<string, string>>>({});
  const [hasExistingRules, setHasExistingRules] = useState<boolean>(false);
  const [hasFetchedCorrectionData, setHasFetchedCorrectionData] = useState<boolean>(false);
  const [correctedFilePath, setCorrectedFilePath] = useState<string | null>(null);
  const [fromRoute, setFromRoute] = useState<string | null>(null);
  const [errorRows, setErrorRows] = useState<any[]>([]);
  const [errorReasons, setErrorReasons] = useState<Record<string, string>>({});
  const [frequencyDialogOpen, setFrequencyDialogOpen] = useState(false);
  const [frequency, setFrequency] = useState<'WEEKLY' | 'MONTHLY' | 'YEARLY' | ''>('');
  const initialFetchDone = useRef<boolean>(false);
  const sftpCredentials = location.state?.sftpCredentials || JSON.parse(localStorage.getItem('sftpCredentials') || '{}');
  const [basicRules, setBasicRules] = useState<Rule[]>([]);
  const [customRules, setCustomRules] = useState<Rule[]>([]);
  const [checkedCustomRules, setCheckedCustomRules] = useState<{ [key: number]: boolean }>({});
  const [validationCompleted, setValidationCompleted] = useState(false);
  const [validationLoading, setValidationLoading] = useState(false);
  const [validationResults, setValidationResults] = useState<any[]>([]);
  // Define CorrectionValidity type
  type CorrectionValidity = Record<string, boolean>;
  const [correctionValidity, setCorrectionValidity] = useState<CorrectionValidity>({});

  useEffect(() => {
  const query = new URLSearchParams(location.search);
  const from = query.get('from');
  setFromRoute(from);

  const fetchTemplate = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await apiService.getTemplate(Number(templateId), sheetName || 'Sheet1');
      const data = response.data as TemplateResponse;
      const actualSheetName = data.sheet_name;
      if (!actualSheetName || !data.sheets || !data.sheets[actualSheetName]) {
        throw new Error('Sheet data not found in the response.');
      }
      setSheetName(actualSheetName);
      setFileName(data.file_name);
      const fetchedHeaders = data.sheets[actualSheetName].headers;
      if (!fetchedHeaders || fetchedHeaders.length === 0) {
        throw new Error('No headers found in the file.');
      }
      setHeaders(fetchedHeaders);
      // Prioritize query step, else use has_existing_rules for rule-configurations
      const queryStep = query.get('step') ? parseInt(query.get('step')!) : null;
      const step = queryStep !== null ? queryStep : (from === 'rule-configurations' && data.has_existing_rules ? 3 : 1);
      console.log('Setting step:', step, 'fromRoute:', from, 'has_existing_rules:', data.has_existing_rules);
      setCurrentStep(step);
      if (!initialFetchDone.current) {
        setHasExistingRules(data.has_existing_rules || false);
        initialFetchDone.current = true;
      }

      if (from === 'rule-configurations' && step === 3) {
        const rulesResponse = await apiService.getTemplateRules(Number(templateId));
        if (rulesResponse.data.success) {
          setSelectedHeaders(Object.keys(rulesResponse.data.rules));
          setValidations(rulesResponse.data.rules);
          setIsReviewMode(true);
        } else {
          console.error('Failed to fetch rules for Step 3:', rulesResponse.data);
          toast({
            title: 'Error',
            description: rulesResponse.data.message || 'Failed to load configured rules.',
            variant: 'destructive',
          });
          // Fallback to Step 1 if rules cannot be fetched
          setCurrentStep(1);
          navigate(`/validate/${templateId}?step=1&from=rule-configurations`);
        }
      }
    } catch (error: any) {
      setError(error.response?.data?.error || error.message || 'Failed to load template headers.');
      toast({ title: 'Error', description: error.response?.data?.error || error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  fetchTemplate();
}, [templateId, sheetName, setHeaders, setCurrentStep, location.search]);

useEffect(() => {
  const fetchRules = async () => {
    try {
      const response = await apiService.getRules();
      const allRules = response.data.rules || [];
      setBasicRules(allRules.filter((rule) => !rule.is_custom));
      const templateCustomRules = allRules.filter(
        (rule) => rule.is_custom && rule.template_id === Number(templateId)
      );
      setCustomRules(templateCustomRules);
      // Initialize checkedCustomRules with all custom rules unchecked
      const initialCheckedState = templateCustomRules.reduce((acc, rule) => ({
      ...acc,
      [rule.rule_id!]: false,
      }), {});
      console.log('Initializing checkedCustomRules for Step', currentStep, ':', initialCheckedState); // Debug log
      setCheckedCustomRules(initialCheckedState);
    } catch (error) {
      console.error('Error fetching rules:', error);
      if (currentStep === 2) {
        toast({
          title: 'Error',
          description: 'Failed to load rules.',
          variant: 'destructive',
        });
      }
    }
  };
  fetchRules();
}, [templateId, currentStep]); // Depend on currentStep to re-run when step changes

// Add new useEffect for custom rules in Step 3
useEffect(() => {
  if (currentStep === 3 && templateId) {
    const fetchCustomRules = async () => {
      try {
        const response = await apiService.getRules();
        const appliedCustomRules = response.data.rules.filter(
          (rule) => rule.is_custom && rule.template_id === Number(templateId)
        );
        setCustomRules(appliedCustomRules);
        // Initialize checkedCustomRules for Step 3 only, marking rules that are applied
        setCheckedCustomRules(
          appliedCustomRules.reduce((acc, rule) => ({
            ...acc,
            [rule.rule_type_id]: Object.values(validations).some((rules) =>
              rules.includes(rule.rule_name)
            ),
          }), {})
        );
      } catch (error) {
        console.error('Error fetching custom rules for Step 3:', error);
        toast({
          title: 'Error',
          description: 'Failed to load custom rules for review.',
          variant: 'destructive',
        });
      }
    };
    fetchCustomRules();
  } else if (currentStep === 2 && templateId) {
    // For Step 2, initialize checkedCustomRules as all unchecked
    const fetchCustomRules = async () => {
      try {
        const response = await apiService.getRules();
        const templateCustomRules = response.data.rules.filter(
          (rule) => rule.is_custom && rule.template_id === Number(templateId)
        );
        setCustomRules(templateCustomRules);
       setCheckedCustomRules((prev) => {
  const currentRuleIds = new Set(templateCustomRules.map(rule => rule.rule_id!));
  const prevRuleIds = new Set(Object.keys(prev).map(id => Number(id)));
  if (
    Object.keys(prev).length === 0 ||
    ![...currentRuleIds].every(id => prevRuleIds.has(id)) ||
    ![...prevRuleIds].every(id => currentRuleIds.has(id))
  ) {
    return templateCustomRules.reduce((acc, rule) => ({
      ...acc,
      [rule.rule_id!]: prev[rule.rule_id!] ?? false,
    }), {});
  }
  return prev;
});
      } catch (error) {
        console.error('Error fetching custom rules for Step 2:', error);
        toast({
          title: 'Error',
          description: 'Failed to load custom rules.',
          variant: 'destructive',
        });
      }
    };
    fetchCustomRules();
  }
}, [currentStep, templateId, validations]);

useEffect(() => {
  if (currentStep === 4 && !hasFetchedCorrectionData && !fetchingErrors) {
    setFetchingErrors(true);
    fetchCorrectionData();
  }
}, [currentStep, hasFetchedCorrectionData, fetchingErrors]);

const fetchCorrectionData = async () => {
    try {
        console.log('Fetching correction data for templateId:', templateId);
        const response = await apiService.validateExistingTemplate(Number(templateId));
        console.log('Backend validation response:', JSON.stringify(response.data, null, 2));

        const newErrorLocations = response.data.error_cell_locations || {};
        const newDataRows = response.data.data_rows || [];

        if (!newErrorLocations || !newDataRows) {
            console.error('Invalid response format: error_cell_locations or data_rows missing');
            throw new Error('Invalid response format from server');
        }

        const normalizedDataRows = newDataRows.map((row: any) => {
            const normalizedRow = { ...row };
            Object.keys(normalizedRow).forEach((key) => {
                if (
                    normalizedRow[key] === null ||
                    normalizedRow[key] === undefined ||
                    normalizedRow[key] === 'NULL'
                ) {
                    normalizedRow[key] = 'NULL';
                }
            });
            return normalizedRow;
        });

        // Aggregate all failed rules for each row, including Alphanumeric
        const reasons: Record<string, string[]> = {};
        Object.entries(newErrorLocations).forEach(([header, errors]: [string, ErrorLocation[]]) => {
            errors.forEach((error: ErrorLocation) => {
                const rowIndex = error.row - 1;
                if (rowIndex >= 0 && rowIndex < normalizedDataRows.length) {
                    const rowKey = rowIndex.toString();
                    if (!reasons[rowKey]) reasons[rowKey] = [];
                    const ruleName = error.rule_failed;
                    const reasonText =
                        error.value === 'NULL' && ruleName === 'Required'
                            ? 'Contains No Data'
                            : ruleName === 'Alphanumeric' && error.reason.includes('non-alphanumeric characters')
                            ? `Contains non-alphanumeric characters: ${error.reason.split(': ')[1] || error.value}`
                            : error.reason;
                    reasons[rowKey].push(`${header}: ${ruleName} - ${reasonText}`);
                }
            });
        });

        // Convert reasons to string for display
        const reasonsDisplay: Record<string, string> = {};
        Object.entries(reasons).forEach(([rowKey, reasonArr]) => {
            reasonsDisplay[rowKey] = reasonArr.join('; ');
        });

        console.log('Processed error locations:', JSON.stringify(newErrorLocations, null, 2));
        console.log('Processed error reasons:', JSON.stringify(reasonsDisplay, null, 2));
        console.log('Processed data rows sample:', JSON.stringify(normalizedDataRows.slice(0, 2), null, 2));

        if (Object.keys(newErrorLocations).length === 0) {
            console.warn('No error locations detected by backend.');
        }

        setErrorLocations(newErrorLocations);
        setDataRows(normalizedDataRows);
        setErrorRows(normalizedDataRows);
        setErrorReasons(reasonsDisplay);
        setHasFetchedCorrectionData(true);
        setFetchingErrors(false);
    } catch (error: any) {
        console.error('Error fetching correction data:', error);
        toast({
            title: 'Error',
            description:
                error.response?.data?.message ||
                error.message ||
                'Failed to fetch validation errors.',
            variant: 'destructive',
        });
        setFetchingErrors(false);
        throw error;
    }
};

  const validateRules = (): boolean => {
  const allowedRules = ['Text', 'Int', 'Float', 'Email', 'Date', 'Boolean', 'Alphanumeric'];  // Change 'AlphaNumeric' to 'Alphanumeric' (lowercase 'n')
  console.log('Validating rules with validations state:', validations);
  for (const header of selectedHeaders) {
    const rules = validations[header] || [];
    console.log(`Header: ${header}, Applied rules:`, rules);
    if (!rules.includes('Required')) {
      console.log(`Validation failed for ${header}: Missing 'Required' rule`);
      toast({
        title: 'Validation Error',
        description: "'Required' rule is mandatory for each column.",
        variant: 'destructive',
      });
      return false;
    }
    const additionalRules = rules.filter((rule) => allowedRules.includes(rule));
    console.log(`Header: ${header}, Additional rules:`, additionalRules);
    if (additionalRules.length !== 1) {
      console.log(`Validation failed for ${header}: Expected 1 additional rule, found ${additionalRules.length}`);
      toast({
        title: 'Validation Error',
        description: "Please select exactly one of 'Text', 'Int', 'Float', 'Email', 'Date', 'Boolean', 'Alphanumeric' and 'Required' is mandatory.",  // Change 'AlphaNumeric' to 'Alphanumeric' (lowercase 'n')
        variant: 'destructive',
      });
      return false;
    }
  }
  console.log('All validations passed');
  return true;
};

const validateCorrection = async (header: string, row: number, value: string): Promise<boolean> => {
  const rules = validations[header] || [];
  let isValid = true;
  let errorMessage = '';

  // Validate basic rules
  for (const rule of rules) {
    if (!isValid) break;
    const customRule = customRules.find((r) => r.rule_name === rule);
    if (customRule) {
      try {
        const response = await apiService.validateColumnRules(Number(templateId));
        const errors = response.data.errors[rule] || [];
        const rowError = errors.find((err: any) => err.row === row + 1 && err.value === value);
        if (rowError) {
          isValid = false;
          errorMessage = rowError.reason;
        }
      } catch (error: any) {
        console.error(`Error validating custom rule ${rule}:`, error);
        isValid = false;
        errorMessage = `Failed to validate custom rule '${rule}'`;
      }
    } else {
      switch (rule) {
        case 'Required':
          if (!value || value.trim() === '' || value === 'NULL') {
            isValid = false;
            errorMessage = 'Value is required';
          }
          break;
        case 'Int':
          if (value && !/^-?\d+$/.test(value)) {
            isValid = false;
            errorMessage = 'Value must be an integer';
          }
          break;
        case 'Float':
          if (value && !/^-?\d*\.?\d+$/.test(value)) {
            isValid = false;
            errorMessage = 'Value must be a number (integer or decimal)';
          }
          break;
        case 'Email':
          const emailRegex = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
          if (value && !emailRegex.test(value)) {
            isValid = false;
            errorMessage = 'Invalid email format';
          }
          break;
        case 'Date':
          const dateFormats = ['\\d{2}-\\d{2}-\\d{4}', '\\d{2}/\\d{2}/\\d{4}', '\\d{4}-\\d{2}-\\d{2}'];
          const dateRegex = new RegExp(`^(${dateFormats.join('|')})$`);
          if (value && !dateRegex.test(value)) {
            isValid = false;
            errorMessage = 'Invalid date format (e.g., DD-MM-YYYY)';
          }
          break;
        case 'Text':
          const hasSpecial = /[^a-zA-Z\s"()]/g.test(value);
          if (value && hasSpecial) {
            isValid = false;
            errorMessage = 'Only letters, spaces, quotes, and parentheses are allowed';
          }
          break;
        case 'Boolean':
          if (value && !/^(true|false|0|1)$/i.test(value)) {
            isValid = false;
            errorMessage = 'Value must be a boolean (true/false or 0/1)';
          }
          break;
        case 'Alphanumeric':
          if (value && !/^[a-zA-Z0-9]+$/.test(value)) {
            isValid = false;
            errorMessage = `Only alphanumeric characters are allowed; found invalid characters: ${value.replace(/[a-zA-Z0-9]/g, '')}`;
          }
          break;
      }
    }
  }

  if (!isValid) {
    toast({ title: 'Validation Error', description: errorMessage, variant: 'destructive' });
  }

  return isValid;
};

const handleValidateCorrected = async () => {
  setValidationLoading(true);
  try {
    // Ensure corrections are saved and corrected file path is available
    let filePath = correctedFilePath;
    if (!filePath) {
      console.log('No corrected file path, saving corrections...');
      filePath = await handleValidateExisting();
      if (!filePath) {
        throw new Error('Failed to generate corrected file for validation. Please reapply corrections in Step 5.');
      }
      setCorrectedFilePath(filePath);
    }

    const response = await apiService.validateCorrectedTemplate(Number(templateId));
    console.log('validateCorrectedTemplate response:', JSON.stringify(response.data, null, 2));

    // Store validation results
    setValidationResults(response.data.results || []);
    setValidationCompleted(true);

    if (!response.data.success) {
      const errorDetails = response.data.results
        .filter((result: any) => result.errors.length > 0)
        .map((result: any) =>
          result.errors.map((err: any) =>
            `Row ${err.row}, Column ${result.column_name}: Rule "${result.rule_name}" failed - ${err.reason}`
          )
        )
        .flat()
        .join('; ');
      toast({
        title: 'Validation Error',
        description: errorDetails || response.data.message || 'Validation failed with errors',
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'Success',
        description: 'Corrected template validated successfully .',
        variant: 'default',
      });
    }
  } catch (error: any) {
    console.error('Error in handleValidateCorrected:', error.response?.data || error.message);
    const errorMessage = error.response?.data?.message || error.message || 'Failed to validate corrected template';
    toast({
      title: 'Validation Error',
      description: errorMessage,
      variant: 'destructive',
    });
    setValidationCompleted(true); // Allow download even if validation fails
    setValidationResults(error.response?.data?.results || []);
    if (errorMessage.includes('No validation rules configured')) {
      if (window.confirm('No validation rules configured. Would you like to configure rules now?')) {
        navigate(`/validate/${templateId}?step=2&from=rule-configurations`);
      }
    } else if (errorMessage.includes('Please reapply corrections') || errorMessage.includes('Session data missing')) {
      if (window.confirm('Corrections or session data missing. Would you like to reapply corrections in Step 5?')) {
        navigate(`/validate/${templateId}?step=5&from=${fromRoute || 'data-validations'}`);
      }
    }
  } finally {
    setValidationLoading(false);
  }
};

const handleDownloadValidationReport = async () => {
  try {
    // Ensure corrections are saved before downloading the report
    let filePath = correctedFilePath;
    if (!filePath) {
      console.log('No corrected file path, saving corrections...');
      filePath = await handleValidateExisting();
      if (!filePath) {
        throw new Error('Failed to generate corrected file for validation report.');
      }
      setCorrectedFilePath(filePath);
    }

    console.log('Downloading validation report for templateId:', templateId);
    await apiService.downloadValidationReport(Number(templateId));
    toast({
      title: 'Success',
      description: 'Validation report download initiated.',
      variant: 'default',
    });
  } catch (error: any) {
    console.error('Error downloading validation report:', error.response?.data || error.message);
    toast({
      title: 'Error',
      description: error.response?.data?.message || error.message || 'Failed to download validation report.',
      variant: 'destructive',
    });
  }
};

const handleStepSubmit = async (step: number, data: any, action: string = 'save') => {
  try {
    let response;
    switch (step) {
      case 1:
        response = await apiService.submitStepOne({
          headers: data?.headers || selectedHeaders,
          new_header_row: data?.new_header_row,
        });
        if (response.data.success) {
          setSelectedHeaders(data.headers);
          setValidations(response.data.validations || {}); // Set auto-assigned validations
          setCurrentStep(2);
          setIsReviewMode(false);
          navigate(`/validate/${templateId}?2${fromRoute ? `&from=${fromRoute}` : ''}`);
        }
        break;
      case 2:
        if (action === 'review' && !validateRules()) return;
        response = await apiService.submitStepTwo({
          validations: data?.validations || validations,
          action: action,
        });
        if (response.data.success) {
          if (action === 'save') {
            toast({ title: 'Success', description: 'Rules saved successfully', variant: 'default' });
            const templatesResponse = await apiService.getRuleConfigurations();
            navigate(fromRoute === 'rule-configurations' ? '/rule-configurations' : '/dashboard', {
              state: { updatedTemplates: templatesResponse.data.templates },
            });
          } else if (action === 'review') {
            toast({ title: 'Success', description: 'Validation rules saved. Moving to review.', variant: 'default' });
            setCurrentStep(3);
            setIsReviewMode(true);
            navigate(`/validate/${templateId}?step=3${fromRoute ? `&from=${fromRoute}` : ''}`);
          }
        }
        break;
      default:
        throw new Error(`Invalid step: ${step}`);
    }
  } catch (error: any) {
    toast({ title: `Step ${step} Error`, description: error.response?.data?.error || `Failed to complete step ${step}.`, variant: 'destructive' });
  }
};

const handleValidateExisting = async () => {
  try {
    console.log('Saving corrections for templateId:', templateId, 'corrections:', corrections);
    const response = await apiService.saveExistingTemplateCorrections(Number(templateId), corrections);
    console.log('saveExistingTemplateCorrections response:', response.data);
    
    if (!response.data.success || !response.data.corrected_file_path) {
      console.error('No corrected_file_path returned or request failed:', response.data);
      throw new Error(response.data.message || 'Failed to save corrections');
    }
    
    toast({ title: 'Success', description: 'Corrections saved successfully', variant: 'default' });
    setCorrectedFilePath(response.data.corrected_file_path);
    return response.data.corrected_file_path;
  } catch (error: any) {
    console.error('Error in handleValidateExisting:', error.response?.data || error.message);
    const errorMessage = error.response?.data?.message || error.message || 'Failed to save corrections';
    toast({
      title: 'Error',
      description: errorMessage,
      variant: 'destructive',
    });
    throw error;
  }
};

  const handleValidationChange = (header: string, rule: string, checked: boolean) => {
  console.log(`handleValidationChange: header=${header}, rule=${rule}, checked=${checked}`);
  const newValidations = { ...validations };
  if (!newValidations[header]) newValidations[header] = ['Required'];

  const genericRules = ['Int', 'Float', 'Text', 'Email', 'Date', 'Boolean', 'AlphaNumeric'];

  if (checked) {
    if (genericRules.includes(rule)) {
      const existingGenericRules = newValidations[header].filter((r) => genericRules.includes(r));
      if (existingGenericRules.length > 0) {
        console.log(`Validation error: ${header} already has generic rule(s):`, existingGenericRules);
        toast({
          title: 'Validation Error',
          description: 'Only one generic rule is allowed per column.',
          variant: 'destructive',
        });
        return;
      }
    }
    newValidations[header].push(rule);
    console.log(`Added rule ${rule} to ${header}. New validations:`, newValidations[header]);
  } else if (rule !== 'Required') {
    newValidations[header] = newValidations[header].filter((r) => r !== rule);
    if (!newValidations[header].includes('Required')) {
      newValidations[header].unshift('Required');
    }
    console.log(`Removed rule ${rule} from ${header}. New validations:`, newValidations[header]);
  } else {
    console.log(`Cannot remove 'Required' rule from ${header}`);
    toast({
      title: 'Validation Error',
      description: "'Required' rule cannot be removed.",
      variant: 'destructive',
    });
    return;
  }
  setValidations(newValidations);
};

  const handleCorrectionChange = async (header: string, row: number, value: string) => {
  const isValid = await validateCorrection(header, row, value);
  setCorrections((prev) => {
    const newCorrections = { ...prev };
    if (!newCorrections[header]) newCorrections[header] = {};
    newCorrections[header][row.toString()] = value;
    return newCorrections;
  });
  setCorrectionValidity((prev) => {
    const newValidity = { ...prev };
    if (!newValidity[header]) newValidity[header] = {};
    newValidity[header][row.toString()] = isValid;
    return newValidity;
  });
};

const allErrorsCorrected = () => {
  return Object.entries(errorLocations).every(([header, errors]) =>
    errors.every((error: ErrorLocation) => {
      const row = (error.row - 1).toString();
      return (
        correctionValidity[header]?.[row] === true &&
        corrections[header]?.[row] !== undefined &&
        corrections[header][row] !== ''
      );
    })
  );
};

const onDragEnd = (result: DropResult) => {
  const { source, destination } = result;
  if (!destination) return;

  const header = destination.droppableId.replace('applied-', '');
  const isAppliedDroppable = destination.droppableId.startsWith('applied-');
  const isAvailableDroppable = source.droppableId === 'available-rules';
  const isTemplateCustomDroppable = source.droppableId === 'template-custom-rules';

  console.log(`onDragEnd: source=${source.droppableId}, destination=${destination.droppableId}, header=${header}`);

  if (isAppliedDroppable && (isAvailableDroppable || isTemplateCustomDroppable)) {
    const ruleList = isAvailableDroppable ? basicRules : customRules;
    const ruleObj = ruleList[source.index];
    const rule = ruleObj.rule_name;

    console.log(`Applying rule ${rule} to header ${header}`);

    const genericRules = ['Int', 'Float', 'Text', 'Email', 'Date', 'Boolean', 'AlphaNumeric'];
    if (isAvailableDroppable && genericRules.includes(rule)) {
      const existingGenericRules = (validations[header] || []).filter((r) => genericRules.includes(r));
      console.log(`Checking existing generic rules for ${header}:`, existingGenericRules);
      if (existingGenericRules.length > 0) {
        console.log(`Validation error: ${header} already has generic rule(s):`, existingGenericRules);
        toast({
          title: 'Validation Error',
          description: 'Only one generic rule is allowed per column.',
          variant: 'destructive',
        });
        return;
      }
    }

    handleValidationChange(header, rule, true);

    if (isTemplateCustomDroppable) {
      setCheckedCustomRules((prev) => ({
        ...prev,
        [ruleObj.rule_type_id]: true,
      }));
      console.log(`Checked custom rule ${rule} for header ${header}`);
    }
  } else if (isAppliedDroppable && source.droppableId === destination.droppableId) {
    const newRules = [...(validations[header] || []).filter((r) => r !== 'Required')];
    const [reorderedRule] = newRules.splice(source.index, 1);
    newRules.splice(destination.index, 0, reorderedRule);
    setValidations({ ...validations, [header]: ['Required', ...newRules] });
    console.log(`Reordered rules for ${header}:`, ['Required', ...newRules]);
  } else if (
    source.droppableId.startsWith('applied-') &&
    (destination.droppableId === 'available-rules' || destination.droppableId === 'template-custom-rules')
  ) {
    const sourceHeader = source.droppableId.replace('applied-', '');
    const rule = (validations[sourceHeader] || []).filter((r) => r !== 'Required')[source.index];
    if (rule) {
      handleValidationChange(sourceHeader, rule, false);
      const customRule = customRules.find((r) => r.rule_name === rule);
      if (customRule) {
        setCheckedCustomRules((prev) => ({
          ...prev,
          [customRule.rule_type_id]: false,
        }));
        console.log(`Unchecked custom rule ${rule} for header ${sourceHeader}`);
      }
    }
  }
};

  const validateInput = (header: string, value: string): boolean => {
  const rules = validations[header] || [];
  let isValid = true;
  let errorMessage = '';

  console.log(`Validating input for header ${header}: value=${value}, rules=`, rules);

  rules.forEach((rule) => {
    if (!isValid) return;
    const customRule = customRules.find((r) => r.rule_name === rule);
    if (customRule) {
      errorMessage = `Custom rule '${rule}' requires backend validation`;
      isValid = false; // Defer to backend validation
    } else {
      switch (rule) {
        case 'Required':
          if (!value || value.trim() === '' || value === 'NULL') {
            isValid = false;
            errorMessage = 'Value is required';
          }
          break;
        case 'Int':
          if (value && !/^-?\d+$/.test(value)) {
            isValid = false;
            errorMessage = 'Value must be an integer';
          }
          break;
        case 'Float':
          if (value && !/^-?\d*\.?\d+$/.test(value)) {
            isValid = false;
            errorMessage = 'Value must be a number (integer or decimal)';
          }
          break;
        case 'Email':
          const emailRegex = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
          if (value && !emailRegex.test(value)) {
            isValid = false;
            errorMessage = 'Invalid email format';
          }
          break;
        case 'Date':
          const dateFormats = ['\\d{2}-\\d{2}-\\d{4}', '\\d{2}/\\d{2}/\\d{4}', '\\d{4}-\\d{2}-\\d{2}'];
          const dateRegex = new RegExp(`^(${dateFormats.join('|')})$`);
          if (value && !dateRegex.test(value)) {
            isValid = false;
            errorMessage = 'Invalid date format (e.g., DD-MM-YYYY)';
          }
          break;
        case 'Text':
          const hasSpecial = /[^a-zA-Z\s"()]/g.test(value);
          if (value && hasSpecial) {
            isValid = false;
            errorMessage = 'Only letters, spaces, quotes, and parentheses are allowed';
          }
          break;
        case 'Boolean':
          if (value && !/^(true|false|0|1)$/i.test(value)) {
            isValid = false;
            errorMessage = 'Value must be a boolean (true/false or 0/1)';
          }
          break;
        case 'AlphaNumeric':
          if (value && !/^[a-zA-Z0-9]+$/.test(value)) {
            isValid = false;
            errorMessage = `Only alphanumeric characters are allowed; found invalid characters: ${value.replace(/[a-zA-Z0-9]/g, '')}`;
          }
          break;
      }
    }
  });

  if (!isValid) {
    console.log(`Validation failed for ${header}: ${errorMessage}`);
    toast({ title: 'Validation Error', description: errorMessage, variant: 'destructive' });
  }

  return isValid;
};

const handleDownload = async () => {
  try {
    let filePath = correctedFilePath;
    console.log('Attempting to download file:', filePath);
    
    if (!filePath) {
      console.log('No corrected file path available, saving corrections...');
      filePath = await handleValidateExisting();
      if (!filePath) {
        console.error('Failed to generate corrected file path');
        throw new Error('Failed to generate corrected file.');
      }
      setCorrectedFilePath(filePath);
    }

    // Extract filename from filePath and ensure it has '_corrected' suffix
    const filename = filePath.split('/').pop() || filePath.split('\\').pop() || '';
    const baseName = filename.split('.').slice(0, -1).join('.');
    const ext = filename.includes('.') ? `.${filename.split('.').pop()}` : '';
    const correctedFilename = baseName.endsWith('_corrected') ? filename : `${baseName}_corrected${ext}`;
    console.log('Filename for download:', correctedFilename);
    
    if (!correctedFilename.includes('_corrected')) {
      console.warn('Filename does not include "_corrected" suffix:', correctedFilename);
    }

    apiService.downloadFile(correctedFilename);
    toast({ title: 'Success', description: 'File download initiated.', variant: 'default' });
    
    if (fromRoute === 'data-validations') {
      navigate('/dashboard');
    }
  } catch (error: any) {
    console.error('Error in handleDownload:', error.response?.data || error.message);
    toast({
      title: 'Error',
      description: error.message || 'Failed to download corrected file.',
      variant: 'destructive',
    });
  }
};

  const handleSaveAndReview = async () => {
  try {
    const filePath = await handleValidateExisting();
    if (!filePath) throw new Error('Failed to save corrections.');
    setCorrectedFilePath(filePath);
    setCurrentStep(6);
    navigate(`/validate/${templateId}?step=6${fromRoute ? `&from=${fromRoute}` : ''}`);
    toast({ title: 'Success', description: 'Corrections saved. Moving to review.', variant: 'default' });
  } catch (error: any) {
    toast({ title: 'Error', description: error.message || 'Failed to save corrections.', variant: 'destructive' });
  }
};

  const handleRetry = () => {
    setLoading(true);
    setError(null);
    const fetchTemplate = async () => {
      try {
        const response = await apiService.getTemplate(Number(templateId), sheetName || 'Sheet1');
        const data = response.data as TemplateResponse;
        const actualSheetName = data.sheet_name;
        if (!actualSheetName || !data.sheets || !data.sheets[actualSheetName]) {
          throw new Error('Sheet data not found in the response.');
        }
        setSheetName(actualSheetName);
        setFileName(data.file_name);
        const fetchedHeaders = data.sheets[actualSheetName].headers;
        if (!fetchedHeaders || fetchedHeaders.length === 0) {
          throw new Error('No headers found in the file.');
        }
        setHeaders(fetchedHeaders);
        setCurrentStep(1);
        setIsReviewMode(false);
        setHasExistingRules(data.has_existing_rules || false);
        initialFetchDone.current = false;
      } catch (error: any) {
        setError(error.response?.data?.error || error.message || 'Failed to load template headers.');
        toast({ title: 'Error', description: error.response?.data?.error || error.message, variant: 'destructive' });
      } finally {
        setLoading(false);
      }
    };
    fetchTemplate();
  };

  // Functional steps for navigation and rendering
  const steps = fromRoute === 'rule-configurations'
    ? [
        { step: 1, label: 'Select Column Headers' },
        { step: 2, label: 'Configure Rules' },
        { step: 3, label: 'Review Configured Rules' },
      ]
    : [
        { step: 1, label: 'Step 1 - Select Column Headers' },
        { step: 2, label: 'Step 2 - Configure Rules' },
        { step: 3, label: 'Step 3 - Review Configured Rules' },
        { step: 4, label: 'Step 1 - Error Detection' },
        { step: 5, label: 'Step 2 - Error Correction' },
        { step: 6, label: 'Step 3 - Review and Finalization' },
      ];

  // Display steps for the progress bar headers
  const displaySteps = fromRoute === 'rule-configurations'
    ? [
        { step: 1, label: 'Select Column Headers' },
        { step: 2, label: 'Configure Rules' },
        { step: 3, label: 'Review Configured Rules' },
      ]
    : currentStep <= 3 // For auto-data-validation configuration flow
    ? [
        { step: 1, label: 'Select Column Headers' },
        { step: 2, label: 'Configure Rules' },
        { step: 3, label: 'Review Configured Rules' },
      ]
    : [
        { step: 4, label: 'Step 1 - Error Detection' },
        { step: 5, label: 'Step 2 - Error Correction' },
        { step: 6, label: 'Step 3 - Review and Finalization' },
      ];

  // Adjust progress calculation based on the current flow
  const adjustedStep = fromRoute !== 'rule-configurations' && currentStep >= 4 ? currentStep - 3 : currentStep;
  const totalSteps = displaySteps.length;
  const progress = (adjustedStep / totalSteps) * 100;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading headers...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center p-6 bg-white rounded-lg shadow-lg border border-gray-200">
          <div className="flex items-center justify-center mb-4">
            <AlertCircle className="h-8 w-8 text-red-600 mr-2" />
            <h2 className="text-xl font-semibold text-gray-800">Error</h2>
          </div>
          <p className="text-red-600 mb-4">{error}</p>
          <p className="text-sm text-gray-600 mb-4">
            Please ensure your file has a valid sheet with headers.
          </p>
          <div className="flex justify-center gap-4">
            <Button
              className="bg-blue-600 hover:bg-blue-700 text-white transition-colors"
              onClick={handleRetry}
            >
              Retry
            </Button>
            <Button
              className="bg-gray-600 hover:bg-gray-700 text-white transition-colors"
              onClick={() => navigate(fromRoute === 'rule-configurations' ? '/rule-configurations' : '/dashboard')}
            >
              Back to {fromRoute === 'rule-configurations' ? 'Rule Configurations' : 'Dashboard'}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 p-8">
        <Card className="shadow-xl border border-gray-200 rounded-lg">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100 border-b border-gray-200">
            <CardTitle className="text-2xl font-bold text-blue-800">
              {fromRoute === 'rule-configurations'
                ? `Configure File - Step ${currentStep}`
                : `Data Validation - ${displaySteps[adjustedStep - 1]?.label || 'Unknown'}`}
            </CardTitle>
            <Button
              variant="outline"
              onClick={() => navigate(fromRoute === 'rule-configurations' ? '/rule-configurations' : '/dashboard')}
              className="flex items-center space-x-2 mt-2 w-fit"
            >
              <Home className="h-5 w-5" />
              <span>{fromRoute === 'rule-configurations' ? 'Rule Configurations' : 'Home'}</span>
            </Button>
          </CardHeader>
          <CardContent className="p-6">
            <div className="mt-4">
              <Progress value={progress} className="w-full h-2 bg-gray-200" />
              <div className="flex justify-between mt-2 text-sm text-gray-600">
                {displaySteps.map((s) => (
                  <span
                    key={s.step}
                    className={`font-medium ${s.step === currentStep ? 'text-blue-600' : 'text-gray-500'}`}
                  >
                    {s.label}
                  </span>
                ))}
              </div>
            </div>
            {fromRoute === 'rule-configurations' ? (
              <>
                {currentStep === 1 && (
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-700">Step 1: Select Column Headers</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Select Column Headers to configure Rules for Error Correction from "{fileName}":
                    </p>
                    {headers.length > 0 ? (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="w-16">Select</TableHead>
                            <TableHead>Header</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {headers.map((header, index) => (
                            <TableRow key={index} className="hover:bg-gray-100 transition-colors">
                              <TableCell>
                                <input
                                  type="checkbox"
                                  value={header}
                                  checked={selectedHeaders.includes(header)}
                                  onChange={(e) => {
                                    const newHeaders = e.target.checked
                                      ? [...selectedHeaders, header]
                                      : selectedHeaders.filter((h) => h !== header);
                                    setSelectedHeaders(newHeaders);
                                  }}
                                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                />
                              </TableCell>
                              <TableCell className="text-gray-800">{header}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    ) : (
                      <p className="text-red-600">No headers available to display.</p>
                    )}
                    <Button
                      className="mt-4 bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      onClick={() => handleStepSubmit(1, { headers: selectedHeaders })}
                      disabled={selectedHeaders.length === 0}
                    >
                      Next
                    </Button>
                  </div>
                )}
                {currentStep === 2 && (
  <div>
    <h3 className="text-lg font-semibold mb-4 text-gray-700">Step 2: Configure Rules</h3>
    <p className="text-sm text-gray-600 mb-4">
      Rules have been automatically assigned based on column data. Drag and drop to modify rules for "{fileName}". The 'Required' rule is mandatory and cannot be removed.
    </p>
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="flex space-x-6">
        <div className="w-1/4">
          <h5 className="text-sm font-semibold text-gray-600 mb-2">Generic Rules</h5>
          <Droppable droppableId="available-rules">
            {(provided) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                className="bg-gray-100 p-4 rounded-lg min-h-[200px] max-h-[300px] overflow-y-auto"
              >
                {basicRules.map((rule, index) => (
                  <Draggable key={rule.rule_name} draggableId={rule.rule_name} index={index}>
                    {(provided) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        className="bg-white p-2 mb-2 rounded shadow-sm border border-gray-200 cursor-move text-center"
                      >
                        {rule.rule_name}
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
          <h5 className="text-sm font-semibold text-gray-600 mb-2 mt-4">Template Custom Rules</h5>
          <Droppable droppableId="template-custom-rules">
            {(provided) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                className="bg-gray-100 p-4 rounded-lg min-h-[200px] max-h-[300px] overflow-y-auto"
              >
                {customRules.map((rule, index) => (
                  <Draggable key={rule.rule_name} draggableId={rule.rule_name} index={index}>
                    {(provided) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        className="bg-white p-2 mb-2 rounded shadow-sm border border-gray-200 cursor-move flex items-center justify-between"
                      >
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            checked={checkedCustomRules[rule.rule_id!] || false}
                            onChange={(e) => {
                              const isChecked = e.target.checked;
                              setCheckedCustomRules((prev) => ({
                                ...prev,
                                [rule.rule_id!]: isChecked,
                              }));
                            }}
                            className="h-4 w-4 mr-2 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                          />
                          {rule.rule_name} (Custom)
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
          <Button
            variant="outline"
            className="mt-2 w-full"
            onClick={() => navigate(`/rules-management?from=rule-configurations&step=2&templateId=${templateId}`)}
          >
            + Add New Custom Rule
          </Button>
        </div>
        <div className="w-3/4">
          <h5 className="text-sm font-semibold text-gray-600 mb-2">Applied Rules</h5>
          <Table>
            <TableHeader>
              <TableRow>
                {selectedHeaders.map((header, index) => (
                  <TableHead key={index} className="text-center">{header}</TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                {selectedHeaders.map((header, index) => (
                  <TableCell key={index} className="p-2">
                    <Droppable droppableId={`applied-${header}`}>
                      {(provided) => (
                        <div
                          {...provided.droppableProps}
                          ref={provided.innerRef}
                          className="bg-blue-50 p-2 rounded min-h-[100px] max-h-[200px] overflow-y-auto"
                        >
                          <div className="bg-blue-100 p-2 mb-1 rounded shadow-sm border border-blue-200 text-center">
                            Required
                          </div>
                          {(validations[header] || []).filter((r) => r !== 'Required').map((rule, ruleIndex) => (
                            <Draggable key={`${header}-${rule}`} draggableId={`${header}-${rule}`} index={ruleIndex}>
                              {(provided) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                  {...provided.dragHandleProps}
                                  className="bg-blue-100 p-2 mb-1 rounded shadow-sm border border-blue-200 flex items-center justify-between"
                                >
                                  <span>{rule}</span>
                                  <button
                                    onClick={() => handleValidationChange(header, rule, false)}
                                    className="text-red-500 hover:text-red-700 text-sm font-bold"
                                    title="Delete rule"
                                  >
                                    X
                                  </button>
                                </div>
                              )}
                            </Draggable>
                          ))}
                          {provided.placeholder}
                        </div>
                      )}
                    </Droppable>
                  </TableCell>
                ))}
              </TableRow>
            </TableBody>
          </Table>
        </div>
      </div>
    </DragDropContext>
    <div className="mt-4 flex space-x-4">
      <Button
        variant="outline"
        className="border-gray-300 text-gray-700 hover:bg-gray-100 transition-colors"
        onClick={() => {
          setCurrentStep(1);
          setIsReviewMode(false);
          navigate(`/validate/${templateId}?step=1${fromRoute ? `&from=${fromRoute}` : ''}`);
        }}
      >
        <ArrowLeft className="h-5 w-5 mr-2" />
        Back
      </Button>
      <Button
        className="bg-blue-600 hover:bg-blue-700 text-white transition-colors"
        onClick={() => handleStepSubmit(2, { validations }, 'review')}
      >
        Save and Review
      </Button>
    </div>
  </div>
)}
                {currentStep === 3 && (
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-700">Step 3: Review Configured Rules</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Review the rule Configurations applied to the selected headers for "{fileName}":
                    </p>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Header</TableHead>
                          {validationOptions.map((rule) => (
                            <TableHead key={rule}>{rule}</TableHead>
                          ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {selectedHeaders.map((header) => (
                          <TableRow key={header}>
                            <TableCell className="text-gray-800">{header}</TableCell>
                            {validationOptions.map((rule) => (
                              <TableCell key={rule}>
                                <input
                                  type="checkbox"
                                  checked={validations[header]?.includes(rule) || false}
                                  disabled={true}
                                  className="h-4 w-4 text-black focus:ring-black border-black rounded"
                                />
                              </TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>

                    {/* New Table for Custom Rules */}
                    {customRules.length > 0 && (
                      <div className="mt-6">
                        <h3 className="text-lg font-semibold mb-4 text-gray-700">Custom Rules Applied</h3>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Rule Name</TableHead>
                              <TableHead>Formula</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {customRules.map((rule) => (
                              <TableRow key={rule.rule_id}>
                                <TableCell className="text-gray-800">{rule.rule_name}</TableCell>
                                <TableCell>{rule.parameters || 'No formula defined'}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}

                    <div className="mt-4 flex space-x-4">
                      <Button
                        className="bg-blue-600 hover:bg-blue-700 text-white transition-colors"
                        onClick={() => {
                          setCurrentStep(2);
                          setIsReviewMode(false);
                          navigate(`/validate/${templateId}?step=2${fromRoute ? `&from=${fromRoute}` : ''}`);
                        }}
                      >
                        Edit
                      </Button>
                      <Button
                        className="bg-blue-600 hover:bg-blue-700 text-white transition-colors"
                        onClick={() => handleStepSubmit(2, { validations }, 'save')}
                      >
                        Finish
                      </Button>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <>
                {currentStep === 1 && fromRoute === 'auto-data-validation' && (
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-700">Step 1: Select Column Headers</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Select Column Headers to configure Rules for Error Correction from "{fileName}":
                    </p>
                    {headers.length > 0 ? (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="w-16">Select</TableHead>
                            <TableHead>Header</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {headers.map((header, index) => (
                            <TableRow key={index} className="hover:bg-gray-100 transition-colors">
                              <TableCell>
                                <input
                                  type="checkbox"
                                  value={header}
                                  checked={selectedHeaders.includes(header)}
                                  onChange={(e) => {
                                    const newHeaders = e.target.checked
                                      ? [...selectedHeaders, header]
                                      : selectedHeaders.filter((h) => h !== header);
                                    setSelectedHeaders(newHeaders);
                                  }}
                                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                />
                              </TableCell>
                              <TableCell className="text-gray-800">{header}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    ) : (
                      <p className="text-red-600">No headers available to display.</p>
                    )}
                    <Button
                      className="mt-4 bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      onClick={() => handleStepSubmit(1, { headers: selectedHeaders })}
                      disabled={selectedHeaders.length === 0}
                    >
                      Next
                    </Button>
                  </div>
                )}
                {currentStep === 2 && fromRoute === 'auto-data-validation' && (
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-700">Step 2: Configure Rules</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Drag and drop one data type rule from the left to apply it to each column header in "{fileName}". Click the 'X' to delete a data type rule. The 'Required' rule is automatically applied and cannot be removed.
                    </p>
                    <DragDropContext onDragEnd={onDragEnd}>
                      <div className="flex space-x-6">
                        <div className="w-1/4">
                          <h5 className="text-sm font-semibold text-gray-600 mb-2">Generic Rules</h5>
                          <Droppable droppableId="available-rules">
                            {(provided) => (
                              <div
                                {...provided.droppableProps}
                                ref={provided.innerRef}
                                className="bg-gray-100 p-4 rounded-lg min-h-[200px] max-h-[300px] overflow-y-auto"
                              >
                                {basicRules.map((rule, index) => (
                                  <Draggable key={rule.rule_name} draggableId={rule.rule_name} index={index}>
                                    {(provided) => (
                                      <div
                                        ref={provided.innerRef}
                                        {...provided.draggableProps}
                                        {...provided.dragHandleProps}
                                        className="bg-white p-2 mb-2 rounded shadow-sm border border-gray-200 cursor-move text-center"
                                      >
                                        {rule.rule_name}
                                      </div>
                                    )}
                                  </Draggable>
                                ))}
                                {provided.placeholder}
                              </div>
                            )}
                          </Droppable>
                          <h5 className="text-sm font-semibold text-gray-600 mb-2 mt-4">Template Custom Rules</h5>
                          <Droppable droppableId="template-custom-rules">
                            {(provided) => (
                              <div
                                {...provided.droppableProps}
                                ref={provided.innerRef}
                                className="bg-gray-100 p-4 rounded-lg min-h-[200px] max-h-[300px] overflow-y-auto"
                              >
                                {customRules.map((rule, index) => (
                                  <Draggable key={rule.rule_name} draggableId={rule.rule_name} index={index}>
                                    {(provided) => (
                                      <div
                                        ref={provided.innerRef}
                                        {...provided.draggableProps}
                                        {...provided.dragHandleProps}
                                        className="bg-white p-2 mb-2 rounded shadow-sm border border-gray-200 cursor-move flex items-center justify-between"
                                      >
                                        <div className="flex items-center">
                                         <input
  type="checkbox"
  checked={checkedCustomRules[rule.rule_id!] || false}
  onChange={(e) => {
    const isChecked = e.target.checked;
    console.log(`Toggling checkbox for rule ${rule.rule_name} (rule_id: ${rule.rule_id}) to ${isChecked}`);
    setCheckedCustomRules((prev) => ({
      ...prev,
      [rule.rule_id!]: isChecked,
    }));
  }}
  className="h-4 w-4 mr-2 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
/>
                                          {rule.rule_name} (Custom)
                                        </div>
                                      </div>
                                    )}
                                  </Draggable>
                                ))}
                                {provided.placeholder}
                              </div>
                            )}
                          </Droppable>
                          <Button
                            variant="outline"
                            className="mt-2 w-full"
                            onClick={() => navigate(`/rules-management?from=rule-configurations&step=2&templateId=${templateId}`)}
                          >
                            + Add New Custom Rule
                          </Button>
                        </div>
                        <div className="w-3/4">
                          <h5 className="text-sm font-semibold text-gray-600 mb-2">Apply Rules to Headers</h5>
                          <Table>
                            <TableHeader>
                              <TableRow>
                                {selectedHeaders.map((header, index) => (
                                  <TableHead key={index} className="text-center">{header}</TableHead>
                                ))}
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              <TableRow>
                                {selectedHeaders.map((header, index) => (
                                  <TableCell key={index} className="p-2">
                                    <Droppable droppableId={`applied-${header}`}>
                                      {(provided) => (
                                        <div
                                          {...provided.droppableProps}
                                          ref={provided.innerRef}
                                          className="bg-blue-50 p-2 rounded min-h-[100px] max-h-[200px] overflow-y-auto"
                                        >
                                          <div className="bg-blue-100 p-2 mb-1 rounded shadow-sm border border-blue-200 text-center">
                                            Required
                                          </div>
                                          {(validations[header] || []).filter((r) => r !== 'Required').map((rule, ruleIndex) => (
                                            <Draggable key={`${header}-${rule}`} draggableId={`${header}-${rule}`} index={ruleIndex}>
                                              {(provided) => (
                                                <div
                                                  ref={provided.innerRef}
                                                  {...provided.draggableProps}
                                                  {...provided.dragHandleProps}
                                                  className="bg-blue-100 p-2 mb-1 rounded shadow-sm border border-blue-200 flex items-center justify-between"
                                                >
                                                  <span>{rule}</span>
                                                  <button
                                                    onClick={() => handleValidationChange(header, rule, false)}
                                                    className="text-red-500 hover:text-red-700 text-sm font-bold"
                                                    title="Delete rule"
                                                  >
                                                    X
                                                  </button>
                                                </div>
                                              )}
                                            </Draggable>
                                          ))}
                                          {provided.placeholder}
                                        </div>
                                      )}
                                    </Droppable>
                                  </TableCell>
                                ))}
                              </TableRow>
                            </TableBody>
                          </Table>
                        </div>
                      </div>
                    </DragDropContext>
                    <div className="mt-4 flex space-x-4">
                      <Button
                        variant="outline"
                        className="border-gray-300 text-gray-700 hover:bg-gray-100 transition-colors"
                        onClick={() => {
                          setCurrentStep(1);
                          setIsReviewMode(false);
                          navigate(`/validate/${templateId}?step=1${fromRoute ? `&from=${fromRoute}` : ''}`);
                        }}
                      >
                        <ArrowLeft className="h-5 w-5 mr-2" />
                        Back
                      </Button>
                      <Button
                        className="bg-blue-600 hover:bg-blue-700 text-white transition-colors"
                        onClick={() => handleStepSubmit(2, { validations }, 'review')}
                      >
                        Save and Review
                      </Button>
                    </div>
                  </div>
                )}
                {currentStep === 3 && fromRoute === 'auto-data-validation' && (
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-700">Step 3: Review Configured Rules</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Review the rule Configurations applied to the selected headers for "{fileName}":
                    </p>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Header</TableHead>
                          {validationOptions.map((rule) => (
                            <TableHead key={rule}>{rule}</TableHead>
                          ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {selectedHeaders.map((header) => (
                          <TableRow key={header}>
                            <TableCell>{header}</TableCell>
                            {validationOptions.map((rule) => (
                              <TableCell key={rule}>
                                <input
                                  type="checkbox"
                                  checked={validations[header]?.includes(rule) || false}
                                  disabled={true}
                                  className="h-4 w-4 text-black focus:ring-black border-black rounded"
                                />
                              </TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                    <Dialog open={frequencyDialogOpen} onOpenChange={setFrequencyDialogOpen}>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Set Validation Frequency</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <Label>Validation Frequency</Label>
                          <select
                            value={frequency}
                            onChange={(e) => setFrequency(e.target.value as 'WEEKLY' | 'MONTHLY' | 'YEARLY')}
                            className="border rounded p-2 w-full"
                          >
                            <option value="">Select Frequency</option>
                            <option value="WEEKLY">Weekly</option>
                            <option value="MONTHLY">Monthly</option>
                            <option value="YEARLY">Yearly</option>
                          </select>
                          <Button
                            className="bg-blue-600 hover:bg-blue-700 text-white transition-colors"
                            onClick={async () => {
                              if (frequency) {
                                await apiService.setValidationFrequency(Number(templateId), { validation_frequency: frequency });
                                setFrequencyDialogOpen(false);
                                handleStepSubmit(2, { validations }, 'save');
                              } else {
                                toast({
                                  title: 'Error',
                                  description: 'Please select a frequency.',
                                  variant: 'destructive',
                                });
                              }
                            }}
                            disabled={!frequency}
                          >
                            Save and Finish
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                    <div className="mt-4 flex space-x-4">
                      <Button
                        className="bg-blue-600 hover:bg-blue-700 text-white transition-colors"
                        onClick={() => {
                          setCurrentStep(2);
                          setIsReviewMode(false);
                          navigate(`/validate/${templateId}?step=2${fromRoute ? `&from=${fromRoute}` : ''}`);
                        }}
                      >
                        Edit
                      </Button>
                      <Button
                        className="bg-blue-600 hover:bg-blue-700 text-white transition-colors"
                        onClick={() => setFrequencyDialogOpen(true)}
                      >
                        Finish
                      </Button>
                    </div>
                  </div>
                )}
{currentStep === 4 && (
    <div>
        <h3 className="text-lg font-semibold mb-4 text-gray-700">Step 1 - Error Detection</h3>
        <p className="text-sm text-gray-600 mb-4">
            The following rows contain errors based on the configured validation rules for "{fileName}":
        </p>
        {fetchingErrors ? (
            <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
                <p className="ml-2 text-gray-600">Fetching errors...</p>
            </div>
        ) : hasFetchedCorrectionData && dataRows.length > 0 ? (
            Object.keys(errorLocations).length > 0 || Object.keys(errorReasons).length > 0 ? (
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Row</TableHead>
                            {headers.map((header, index) => (
                                <TableHead key={index}>{header}</TableHead>
                            ))}
                            <TableHead>Reason</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {dataRows.map((row, rowIndex) => {
                            const rowKey = rowIndex.toString();
                            const hasErrors = Object.keys(errorReasons).includes(rowKey) ||
                                Object.values(errorLocations).some((errors: ErrorLocation[]) =>
                                    errors.some((err) => err.row === rowIndex + 1)
                                );
                            if (!hasErrors) return null;
                            return (
                                <TableRow key={rowIndex}>
                                    <TableCell>{rowIndex + 1}</TableCell>
                                    {headers.map((header, colIndex) => {
                                        const error = errorLocations[header]?.find(
                                            (err: ErrorLocation) => err.row === rowIndex + 1
                                        );
                                        const hasError = !!error;
                                        const displayValue = row[header] === null || row[header] === undefined || row[header] === '' || row[header] === 'NULL'
                                            ? 'NULL'
                                            : row[header];
                                        return (
                                            <TableCell
                                                key={colIndex}
                                                className={hasError ? 'bg-red-100 text-red-600' : ''}
                                            >
                                                {displayValue}
                                                {hasError && error.rule_failed === 'Alphanumeric' && (
                                                    <div className="text-xs text-red-500 mt-1">
                                                        Invalid: {error.reason}
                                                    </div>
                                                )}
                                            </TableCell>
                                        );
                                    })}
                                    <TableCell>{errorReasons[rowKey] || 'Error detected but reason not specified'}</TableCell>
                                </TableRow>
                            );
                        })}
                    </TableBody>
                </Table>
            ) : (
                <p className="text-green-600">No errors found in your file.</p>
            )
        ) : (
            <p className="text-red-600">No data available or failed to load errors. Please try again.</p>
        )}
        <div className="mt-4 flex space-x-4">
            <Button
                className="bg-blue-600 hover:bg-blue-700 text-white transition-colors"
                onClick={() => {
                    setCurrentStep(5);
                    navigate(`/validate/${templateId}?step=5${fromRoute ? `&from=${fromRoute}` : ''}`);
                }}
                disabled={Object.keys(errorReasons).length === 0 || fetchingErrors || !hasFetchedCorrectionData}
            >
                Next
            </Button>
        </div>
    </div>
)}
                {currentStep === 5 && (
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-700">Step 2 - Error Correction</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Correct the errors in the following rows for "{fileName}":
                    </p>
                    {dataRows.length > 0 ? (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Row</TableHead>
                            {headers.map((header, index) => (
                              <TableHead key={index}>{header}</TableHead>
                            ))}
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {dataRows.map((row, rowIndex) => {
                            const rowKey = rowIndex.toString();
                            const hasErrors = Object.keys(errorReasons).includes(rowKey);
                            if (!hasErrors) return null;
                            return (
                              <TableRow key={rowIndex}>
                                <TableCell>{rowIndex + 1}</TableCell>
                                {headers.map((header, colIndex) => {
                                  const error = errorLocations[header]?.find(
                                    (err: ErrorLocation) => err.row === rowIndex + 1
                                  );
                                  const hasError = !!error;
                                  const displayValue = error ? error.value : (row[header] || 'NULL');
                                  return (
                                    <TableCell
                                      key={colIndex}
                                      className={hasError ? 'bg-red-100 text-red-600' : ''}
                                    >
                                      {hasError ? (
                                        <Input
                                          type="text"
                                          defaultValue={corrections[header]?.[rowIndex.toString()] || (displayValue === 'NULL' ? '' : displayValue)}
                                          onChange={(e) => {
                                            if (validateInput(header, e.target.value)) {
                                              handleCorrectionChange(header, rowIndex, e.target.value);
                                            }
                                          }}
                                          placeholder={displayValue === 'NULL' ? 'Enter value' : undefined}
                                          className="border rounded p-2 focus:ring-blue-500 focus:border-blue-500 w-full"
                                        />
                                      ) : (
                                        displayValue
                                      )}
                                    </TableCell>
                                  );
                                })}
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    ) : (
                      <p className="text-green-600">No errors to correct.</p>
                    )}
                    <div className="mt-4 flex space-x-4">
                      <Button
                        variant="outline"
                        className="border-gray-300 text-gray-700 hover:bg-gray-100 transition-colors"
                        onClick={() => {
                          setCurrentStep(4);
                          navigate(`/validate/${templateId}?step=4${fromRoute ? `&from=${fromRoute}` : ''}`);
                        }}
                      >
                        <ArrowLeft className="h-5 w-5 mr-2" />
                        Back
                      </Button>
                      <Button
                        className="bg-blue-600 hover:bg-blue-700 text-white transition-colors"
                        onClick={handleSaveAndReview}
                      >
                        Save and Review
                      </Button>
                    </div>
                  </div>
                )}
                {currentStep === 6 && (
  <div>
    <h3 className="text-lg font-semibold mb-4 text-gray-700">Step 3 - Review and Finalization</h3>
    <p className="text-sm text-gray-600 mb-4">
      Review the corrected data for "{fileName}". Corrected cells are highlighted in green.
    </p>
    {dataRows.length > 0 ? (
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Row</TableHead>
            {headers.map((header, index) => (
              <TableHead key={index}>{header}</TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {dataRows.map((row, rowIndex) => {
            const rowKey = rowIndex.toString();
            const hasErrors = Object.keys(errorReasons).includes(rowKey);
            if (!hasErrors) return null;
            return (
              <TableRow key={rowIndex}>
                <TableCell>{rowIndex + 1}</TableCell>
                {headers.map((header, colIndex) => {
                  const hasError = errorLocations[header]?.some(
                    (err: ErrorLocation) => err.row === rowIndex + 1
                  );
                  const correctedValue = corrections[header]?.[rowIndex.toString()];
                  const displayValue = correctedValue !== undefined ? correctedValue : (row[header] || 'NULL');
                  return (
                    <TableCell
                      key={colIndex}
                      className={hasError && correctedValue !== undefined ? 'bg-green-100 font-semibold' : ''}
                    >
                      {displayValue}
                      {hasError && (
                        <div className="text-xs text-gray-500 mt-1">
                          Original: {row[header] === null || row[header] === undefined || row[header] === '' || row[header] === 'NULL'
                            ? 'NULL'
                            : row[header]}
                        </div>
                      )}
                    </TableCell>
                  );
                })}
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    ) : (
      <p className="text-green-600">No corrections to review.</p>
    )}
    <div className="mt-4 flex space-x-4">
      <Button
        className="bg-blue-600 hover:bg-blue-700 text-white transition-colors"
        onClick={() => {
          setCurrentStep(5);
          navigate(`/validate/${templateId}?step=5${fromRoute ? `&from=${fromRoute}` : ''}`);
        }}
      >
        Edit
      </Button>
      <Button
        className="bg-blue-600 hover:bg-blue-700 text-white transition-colors"
        onClick={handleValidateCorrected}
        disabled={validationLoading}
      >
        {validationLoading ? 'Validating...' : 'Validate'}
      </Button>
      <Button
        className="bg-green-600 hover:bg-green-700 text-white transition-colors"
        onClick={async () => {
          try {
            console.log('Downloading validation report for templateId:', templateId);
            await apiService.downloadValidationReport(Number(templateId));
            toast({
              title: 'Success',
              description: 'Validation report download initiated.',
              variant: 'default',
            });
          } catch (error: any) {
            console.error('Error downloading validation report:', error);
            toast({
              title: 'Error',
              description: error.message || 'Failed to download validation report.',
              variant: 'destructive',
            });
          }
        }}
        disabled={!validationCompleted}
      >
        <Download className="h-5 w-5 mr-2" />
        Download Validate Report
      </Button>
      <Button
        className="bg-blue-600 hover:bg-blue-700 text-white transition-colors"
        onClick={async () => {
          console.log('Finish button clicked: fromRoute=', fromRoute, 'sftpCredentials=', sftpCredentials);
          try {
            await handleValidateExisting();
            if (fromRoute === 'auto-data-validation') {
              console.log('Redirecting to /sftp-dashboard with credentials:', sftpCredentials);
              navigate('/sftp-dashboard', { state: { sftpCredentials } });
            } else {
              console.log('Redirecting to /dashboard');
              navigate('/dashboard');
            }
          } catch (error: any) {
            console.error('Error in handleValidateExisting:', error);
            toast({
              title: 'Error',
              description: error.message || 'Failed to save corrections.',
              variant: 'destructive',
            });
          }
        }}
      >
        Finish
      </Button>
      <Button
        className="bg-green-600 hover:bg-green-700 text-white transition-colors"
        onClick={handleDownload}
        disabled={!correctedFilePath}
      >
        <Download className="h-5 w-5 mr-2" />
        Download Corrected File
      </Button>
      {fromRoute === 'auto-data-validation' && correctedFilePath && (
        <Button
          className="bg-purple-600 hover:bg-purple-700 text-white transition-colors"
          disabled={loading}
          onClick={async () => {
            setLoading(true);
            const sftpData = {
              hostname: sftpCredentials.hostname?.trim() || '',
              username: sftpCredentials.username?.trim() || '',
              password: sftpCredentials.password?.trim() || '',
              folder_path: sftpCredentials.path?.trim() || '/',
            };
            if (!sftpData.hostname || !sftpData.username || !sftpData.password || !sftpData.folder_path) {
              const missing = Object.keys(sftpData).filter(key => !sftpData[key]);
              console.error('Missing SFTP credentials:', missing);
              toast({
                title: 'Error',
                description: `Missing SFTP credentials: ${missing.join(', ')}. Please reconnect via SFTP Dashboard.`,
                variant: 'destructive',
              });
              navigate('/auto-data-validation', { state: { returnTo: `/validate/${templateId}?step=6&from=auto-data-validation` } });
              setLoading(false);
              return;
            }
            let filePath = correctedFilePath;
            if (!filePath) {
              try {
                console.log('Saving corrections before approval');
                filePath = await handleValidateExisting();
                if (!filePath) {
                  throw new Error('Failed to generate corrected file.');
                }
                setCorrectedFilePath(filePath);
              } catch (error: any) {
                console.error('Error saving corrections:', error);
                toast({
                  title: 'Error',
                  description: error.message || 'Failed to save corrections before approval.',
                  variant: 'destructive',
                });
                setLoading(false);
                return;
              }
            }
            try {
              console.log('Approving file with templateId:', templateId, 'filePath:', filePath);
              const response = await apiService.approveSftpFile(Number(templateId), {
                hostname: sftpData.hostname,
                username: sftpData.username,
                password: sftpData.password,
                folder_path: sftpData.folder_path,
                corrected_file_path: filePath,
              });
              console.log('Approve response:', response.data);
              toast({
                title: 'Success',
                description: response.data.message,
                variant: 'default',
              });
              navigate('/sftp-dashboard', { state: { sftpCredentials: sftpData } });
            } catch (error: any) {
              console.error('Approval error:', error.response?.data || error);
              const errorMessage = error.response?.data?.message || error.message || 'Failed to approve file.';
              toast({
                title: 'Error',
                description: errorMessage,
                variant: 'destructive',
              });
            } finally {
              setLoading(false);
            }
          }}
        >
          {loading ? 'Approving...' : 'Approve'}
        </Button>
      )}
      {fromRoute === 'auto-data-validation' && (
        <Button
          variant="outline"
          className="border-gray-300 text-gray-700 hover:bg-gray-100 transition-colors"
          onClick={() => navigate('/sftp-dashboard', { state: { sftpCredentials } })}
        >
          Back to SFTP Dashboard
        </Button>
      )}
    </div>
  </div>
)}
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Validate;