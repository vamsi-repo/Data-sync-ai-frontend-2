import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Sidebar } from '../components/Sidebar';
import { useAuth } from '../contexts/AuthContext';
import { useValidation } from '../contexts/ValidationContext';
import { toast } from '../hooks/use-toast';
import * as apiService from '../services/api';
import ruleConfigurationsIcon from '@/images/Rule Configurations.png'; // Import Rule Configurations icon
import dataValidationsIcon from '@/images/Data Validations.png'; // Import Data Validations icon
// Make sure the image exists at this path, or update the path if needed
import keansaLogo from '@/images/Keansa_Logo.png'; // Import Keansa logo as placeholder for dummy cards
import autodatavalidationicon from '../images/sftp-icon.png'; // Import Auto Data Validation icon
import rulemanagementicon from '../images/Rule Management.png'; // Import Rules Management icon

const Dashboard = () => {
  const { isAuthenticated } = useAuth();
  const { templates, setTemplates, setSelectedTemplate } = useValidation();
  const [loading, setLoading] = useState(true);
  const [username, setUsername] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
  if (isAuthenticated) {
    const fetchUserAndTemplates = async () => {
      try {
        setLoading(true);
        
        // Fetch user details
        const authResponse = await apiService.checkAuthStatus();
        if (authResponse.data.success && authResponse.data.user) {
          setUsername(authResponse.data.user.first_name || authResponse.data.user.email); // Prefer first_name, fallback to email
        } else {
          toast({
            title: 'Error',
            description: 'Failed to load user details.',
            variant: 'destructive',
          });
        }

        // Fetch templates
        const templatesResponse = await apiService.getTemplates();
        const filteredTemplates = templatesResponse.data.templates.filter(
          (template: any) => !('is_corrected' in template) || !template.is_corrected
        );
        setTemplates(filteredTemplates);
      } catch (error) {
        toast({
          title: 'Error',
          description: 'Failed to load dashboard data.',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    fetchUserAndTemplates();
  }
}, [isAuthenticated, setTemplates]);

  const handleCardClick = (path: string) => {
    navigate(path);
  };

  if (!isAuthenticated) return null;

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Keansa logo at top right */}
      <img
        src={keansaLogo}
        alt="Keansa Logo"
        className="absolute top-6 right-8 w-20 h-20 z-20"
        style={{ objectFit: 'contain' }}
      />
      <Sidebar />
      <div className="flex-1 p-8">
        <h1 className="text-2xl font-bold mb-6">Data Sync Ai</h1>
        
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-8 gap-5 overflow-x-auto">
          {/* Increased to 11 columns */}
          <Card
            className="shadow-md hover:shadow-lg transition-shadow cursor-pointer w-32"
            onClick={() => handleCardClick('/rule-configurations')}
          >
            <CardHeader className="flex items-center justify-center">
              <img src={ruleConfigurationsIcon} alt="Rule Configurations" className="w-12 h-12 mb-2" />
            </CardHeader>
            <CardContent className="text-center py-2">
              <CardTitle className="text-xs font-medium text-gray-700 whitespace-normal leading-tight">
                Rule Configurations
              </CardTitle>
            </CardContent>
          </Card>
          <Card
            className="shadow-md hover:shadow-lg transition-shadow cursor-pointer w-32"
            onClick={() => handleCardClick('/data-validations')}
          >
            <CardHeader className="flex items-center justify-center">
              <img src={dataValidationsIcon} alt="Data Validations" className="w-12 h-12 mb-2" />
            </CardHeader>
            <CardContent className="text-center py-2">
              <CardTitle className="text-xs font-medium text-gray-700 whitespace-normal leading-tight">
                Data Validations
              </CardTitle>
            </CardContent>
          </Card>
      
          <Card
            className="shadow-md hover:shadow-lg transition-shadow cursor-pointer w-32"
            onClick={() => handleCardClick('/auto-data-validation')} // Placeholder route
          >
            <CardHeader className="flex items-center justify-center">
              <img src={autodatavalidationicon} alt="Auto Data Validation" className="w-12 h-12 mb-2" />
            </CardHeader>
            <CardContent className="text-center py-2">
              <CardTitle className="text-xs font-medium text-gray-700 whitespace-normal leading-tight">
                Auto Data Validation
              </CardTitle>
            </CardContent>
          </Card>
          <Card
            className="shadow-md hover:shadow-lg transition-shadow cursor-pointer w-32"
            onClick={() => handleCardClick('/rules-management')} // Placeholder route
          >
            <CardHeader className="flex items-center justify-center">
              <img src={rulemanagementicon} alt="Auto Data Validation" className="w-12 h-12 mb-2" />
            </CardHeader>
            <CardContent className="text-center py-2">
              <CardTitle className="text-xs font-medium text-gray-700 whitespace-normal leading-tight">
                Rules Management
              </CardTitle>
            </CardContent>
          </Card>


        </div>
      </div>
    </div>
  );
};

export default Dashboard;